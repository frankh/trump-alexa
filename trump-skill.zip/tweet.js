var Tweet = {
    getRandomTweet: function() {

        return "You're the best";
    }
  }

  module.exports = Tweet;